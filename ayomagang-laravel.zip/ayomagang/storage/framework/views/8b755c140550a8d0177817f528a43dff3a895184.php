<?php $__env->startSection('content'); ?>
 <head>
    <style>
        #login-student::before{
            content: "";
            position: fixed;
            left: 0;
            right: 0;
            z-index: -1;
            display: block;
            background-image: url(<?php echo e(asset('img/carousel/4.jpg')); ?>);
            filter: brightness(70%);
            background-repeat: no-repeat;
            background-size:cover;
            width: 100%;
            height: 100%;
        }
            #login-company::before{
            content: "";
            position: fixed;
            left: 0;
            right: 0;
            z-index: -1;
            display: block;
            background-image: url(<?php echo e(asset('img/carousel/3.jpg')); ?>);
            filter: brightness(70%);
            background-repeat: no-repeat;
            background-size:cover;
            width: 100%;
            height: 100%;
        }
    </style>
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/pt.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('/ico/favicon.png')); ?>">
    <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css'>
    </head>
    <body class="wow fadeIn">
        <div class='easytransitions'>
            <div class='easytransitions_transition'>
                <div class='div easytransitions_transition__part-1 none'></div>
                <div class='div easytransitions_transition__part-2 none'></div>
                <div class='div easytransitions_transition__part-3 none'></div>
                <div class='div easytransitions_transition__part-4 none'></div>
                <div class='div easytransitions_transition__part-5 none'></div>
                <div class='div easytransitions_transition__part-6 none'></div>
                <div class='div easytransitions_transition__part-7 none'></div>
                <div class='div easytransitions_transition__part-8 none'></div>
            </div>
            <!--Student Login-->
          <section class='active_slide' data-transition='wipe_right' id="login-student">
              <div class="container-fluid" >
                  <div class="container" style="padding-top:40px;">
                      <div class="row align-items-center justify-content-start text-left">
                          <div class="col wow fadeInLeft" style="color:white;">
                              <img src="<?php echo e(asset('img/logo/logo_putih_pas.png')); ?>" style="width:30%;">
                              <p style="font-weight:350!important;color:white!important;font-size:24px;">Mencari Magang Akademik Menjadi Lebih Mudah!</p>
                          </div>
                      </div>
                      <div class="row align-items-center justify-content-start text-left">
                          <div class="col-sm-4 wow fadeInLeft">
                              <div class="card rounded border-0" style="background-color:rgba(255,255,255,0);">
                                  <div class="card-body" style="color:white;">
                                      <h1 style="color:white;font-weight:276;font-size:40px;">Student Login</h1>
                                      <form method="post" action="<?php echo e(route('login')); ?>">
                                          <?php echo csrf_field(); ?>
                                          <div class="form-group" style="padding-top:20px;">
                                              <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email Anda">
                                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="invalid-feedback" role="alert">
                                                  <strong><?php echo e($message); ?></strong>
                                              </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                          <div class="form-group" style="padding-bottom:20px;">
                                              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password Anda">
                                              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="invalid-feedback" role="alert">
                                                  <strong><?php echo e($message); ?></strong>
                                              </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                          <div class="form-group">
                                              <div class="form-check">
                                                  <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                  <label class="form-check-label" for="remember">
                                                     <?php echo e(__('Remember Me')); ?>

                                                  </label>
                                              </div>
                                          </div>
                                          <div class="form-group">
                                              <button type="submit" class="btn btn-primary"><?php echo e(__('Masuk')); ?></button>
                                              <?php if(Route::has('password.request')): ?>
                                                  <a class="btn btn-link btn-secondary" href="<?php echo e(route('password.request')); ?>" style="text-decoration: none;color:white;">
                                                    <?php echo e(__('Lupa Password? Reset disini!')); ?>

                                                  </a>
                                              <?php endif; ?>
                                          </div>
                                          <div class="form-group">
                                              <p style="color:white;font-size:19px;">
                                                  Ingin mendaftar ? Klik di <a href="<?php echo e(route('register')); ?>" class="" style="text-decoration: none; color:white;"><b>Sini</b></a><br>
                                                  Atau Ingin Posting job? Klik di <a href="#" class="easytransitions_navigation__right" style="text-decoration: none!important; color:white;"><b>Sini</b></a>
                                              </p>
                                          </div>
                                    </form>
                                    <br>
                                    <a href="http://localhost:8000"><img src="<?php echo e(asset('img/logo/logo%20putih.png')); ?>" style="padding-bottom:20px;"></a>
                                    <h6>Copyright &copy; 2020 Ayo Magang</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>
        <!--Company Login-->
          <section data-transition='wipe_left'>
            <div class="container-fluid" id="login-company">
                <div class="container" style="padding-top:40px;">
                    <div class="row align-items-center justify-content-center text-center">
                        <div class="col wow fadeInLeft" style="color:white;">
                            <img src="<?php echo e(asset('img/logo/logo_putih_pas.png')); ?>" style="width:30%;">
                        </div>
                    </div>
                    <div class="row align-items-center justify-content-end text-right">
                        <div class="col-sm-4 wow fadeInLeft">
                            <div class="card rounded border-0" style="background-color:rgba(255,255,255,0);">
                                <div class="card-body" style="color:white!important;">
                                    <h1 style="color:white;font-weight:276;font-size:40px;">Company Login</h1>
                                    <form method="post" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group" style="padding-top:20px;">
                                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email Anda">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group" style="padding-bottom:20px;">
                                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password Anda">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="remember">
                                                    <?php echo e(__('Remember Me')); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary"><?php echo e(__('Masuk')); ?></button>
                                            <?php if(Route::has('password.request')): ?>
                                                <a class="btn btn-link btn-secondary" href="<?php echo e(route('password.request')); ?>" style="text-decoration: none;color:white;">
                                                    <?php echo e(__('Lupa Password? Reset disini!')); ?>

                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <p style="color:white;font-size:19px;">
                                                Ingin mendaftar ? Klik di <a href="<?php echo e(route('register')); ?>" class="" style="text-decoration: none; color:white;"><b>Sini</b></a><br>
                                                Atau Ingin Cari job? Klik di <a href="#" class="easytransitions_navigation__left" style="text-decoration: none; color:white;"><b>Sini</b></a>
                                            </p>
                                        </div>
                                    </form>
                                    <br>
                                    <a href="http://localhost:8000"><img src="<?php echo e(asset('img/logo/logo%20putih.png')); ?>" style="padding-bottom:20px;"></a>
                                    <h6>Copyright &copy; 2020 Ayo Magang</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>
        </div>
    </body>
    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    <script>
        jQuery(document).ready(function() { 
            new WOW().init();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>