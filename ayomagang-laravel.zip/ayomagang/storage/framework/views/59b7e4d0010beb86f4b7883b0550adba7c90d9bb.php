<?php $__env->startSection('content'); ?>
<!--
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
-->

<head>
    <style>
        #register-student::before{
            content: "";
            position: fixed;
            left: 0;
            right: 0;
            z-index: -1;
            display: block;
            background-image: url(<?php echo e(asset('img/carousel/5.jpg')); ?>);
            filter: brightness(65%);
            background-repeat: no-repeat;
            background-size:cover;
            width: 100%;
            height: 100%;
        }
            #register-company::before{
            content: "";
            position: fixed;
            left: 0;
            right: 0;
            z-index: -1;
            display: block;
            background-image: url(<?php echo e(asset('img/carousel/2.jpg')); ?>);
            filter: brightness(70%);
            background-repeat: no-repeat;
            background-size:cover;
            width: 100%;
            height: 100%;
        }
    </style>
    <title>Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/pt.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('/ico/favicon.png')); ?>">
    <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css'>
    </head>
    <body class="wow fadeIn">
        <div class='easytransitions'>
            <div class='easytransitions_transition'>
                <div class='div easytransitions_transition__part-1 none'></div>
                <div class='div easytransitions_transition__part-2 none'></div>
                <div class='div easytransitions_transition__part-3 none'></div>
                <div class='div easytransitions_transition__part-4 none'></div>
                <div class='div easytransitions_transition__part-5 none'></div>
                <div class='div easytransitions_transition__part-6 none'></div>
                <div class='div easytransitions_transition__part-7 none'></div>
                <div class='div easytransitions_transition__part-8 none'></div>
            </div>
            <!--Student register-->
          <section class='active_slide' data-transition='wipe_right' id="register-student">
              <div class="container-fluid" >
                  <div class="container" style="padding-top:40px;">
                      <div class="row align-items-center justify-content-start text-left">
                          <div class="col wow fadeInLeft" style="color:white;">
                              <img src="<?php echo e(asset('img/logo/logo_putih_pas.png')); ?>" style="width:30%;">
                          </div>
                      </div>
                      <div class="row align-items-center justify-content-start text-left">
                          <div class="col-sm-4 wow fadeInLeft">
                              <div class="card rounded border-0" style="background-color:rgba(255,255,255,0);">
                                  <div class="card-body" style="color:white;">
                                      <h1 style="color:white;font-weight:276;font-size:40px;">Student Register</h1>
                                      <form method="post" action="<?php echo e(route('register')); ?>">
                                          <?php echo csrf_field(); ?>
                                          <div class="form-group" style="padding-top:32px;">
                                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="Nama Lengkap Anda">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                          <div class="form-group">
                                              <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email Anda">
                                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="invalid-feedback" role="alert">
                                                  <strong><?php echo e($message); ?></strong>
                                              </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                          <div class="form-group">
                                              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password Baru Anda">
                                              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="invalid-feedback" role="alert">
                                                  <strong><?php echo e($message); ?></strong>
                                              </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                            <div class="form-group" style="padding-bottom:20px;">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Konfirmasi Password Baru Anda">
                                                
                                                <input id="usertype" type="text" class="form-control <?php $__errorArgs = ['usertype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="usertype" value="Student" required autocomplete="usertype" hidden>
                                            </div>
                                          <div class="form-group">
                                              <button type="submit" class="btn btn-primary"><?php echo e(__('Daftar')); ?></button>
                                          </div>
                                          <div class="form-group">
                                              <p style="color:white;font-size:19px;">
                                                 Sudah Punya Akun? Klik di <a href="<?php echo e(route('login')); ?>" class="" style="text-decoration: none; color:white;"><b>Sini</b></a><br>
                                                 Atau mau daftar jadi employer? Klik di <a href="#" class="easytransitions_navigation__right" style="text-decoration: none!important; color:white;"><b>Sini</b></a>
                                              </p>
                                          </div>
                                    </form>
                                    <br>
                                    <a href="http://localhost:8000"><img src="<?php echo e(asset('img/logo/logo%20putih.png')); ?>" style="padding-bottom:20px;"></a>
                                    <h6>Copyright &copy; 2020 Ayo Magang</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>
        <!--Company register-->
          <section data-transition='wipe_left'>
            <div class="container-fluid" id="register-company">
                <div class="container" style="padding-top:40px;">
                    <div class="row align-items-center justify-content-start text-left">
                        <div class="col wow fadeInLeft" style="color:white;">
                            <img src="<?php echo e(asset('img/logo/logo_putih_pas.png')); ?>" style="width:30%;">
                        </div>
                    </div>
                    <div class="row align-items-center justify-content-start text-left">
                        <div class="col-sm-4 wow fadeInLeft">
                            <div class="card rounded border-0" style="background-color:rgba(255,255,255,0);">
                                <div class="card-body" style="color:white!important;">
                                    <h1 style="color:white;font-weight:276;font-size:40px;">Company Login</h1>
                                    <form method="post" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>
                                          <div class="form-group" style="padding-top:32px;">
                                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="Nama Perusahaan Anda">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                          <div class="form-group">
                                              <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email Anda / Perusahaan Anda">
                                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="invalid-feedback" role="alert">
                                                  <strong><?php echo e($message); ?></strong>
                                              </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                          <div class="form-group">
                                              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password Baru Anda">
                                              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="invalid-feedback" role="alert">
                                                  <strong><?php echo e($message); ?></strong>
                                              </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                            <div class="form-group" style="padding-bottom:20px;">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Konfirmasi Password Baru Anda">
                                                
                                                <input id="usertype" type="text" class="form-control <?php $__errorArgs = ['usertype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="usertype" value="Company" required autocomplete="usertype" hidden>
                                            </div>
                                          <div class="form-group">
                                              <button type="submit" class="btn btn-primary"><?php echo e(__('Daftar')); ?></button>
                                          </div>
                                          <div class="form-group">
                                              <p style="color:white;font-size:19px;">
                                                 Sudah Punya Akun? Klik di <a href="<?php echo e(route('login')); ?>" class="" style="text-decoration: none; color:white;"><b>Sini</b></a><br>
                                                 Atau mau daftar jadi intern / magang?? Klik di <a href="#" class="easytransitions_navigation__left" style="text-decoration: none!important; color:white;"><b>Sini</b></a>
                                              </p>
                                          </div>
                                    </form>
                                    <br>
                                    <a href="http://localhost:8000"><img src="<?php echo e(asset('img/logo/logo%20putih.png')); ?>" style="padding-bottom:20px;"></a>
                                    <h6>Copyright &copy; 2020 Ayo Magang</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>
        </div>
    </body>
    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    <script>
        jQuery(document).ready(function() { 
            new WOW().init();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>